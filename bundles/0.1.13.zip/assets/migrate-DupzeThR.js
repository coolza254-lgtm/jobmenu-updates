var e=[{version:1,name:`001_init`,sql:`
CREATE TABLE meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE cases (
  id TEXT PRIMARY KEY,
  order_no TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  sold_date TEXT NOT NULL,
  items TEXT NOT NULL,
  spec TEXT,
  price_list REAL,
  price_paid REAL,
  payment_method_id TEXT,
  arrival_date TEXT,
  received_date TEXT,
  delivery_method_id TEXT,
  delivery_status_id TEXT,
  status_id TEXT NOT NULL,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_cases_status   ON cases(status_id, is_archived);
CREATE INDEX idx_cases_arrival  ON cases(arrival_date);
CREATE INDEX idx_cases_updated  ON cases(updated_at DESC);
CREATE INDEX idx_cases_order_no ON cases(order_no);

CREATE TABLE case_notes (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL REFERENCES cases(id),
  body TEXT NOT NULL,
  is_system INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_notes_case ON case_notes(case_id, created_at DESC);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT,
  kind TEXT NOT NULL,
  case_id TEXT REFERENCES cases(id),
  priority TEXT NOT NULL DEFAULT 'normal',
  source TEXT,
  source_raw TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_tasks_active ON tasks(is_active, kind);
CREATE INDEX idx_tasks_case   ON tasks(case_id);

CREATE TABLE reminders (
  id TEXT PRIMARY KEY,
  task_id TEXT REFERENCES tasks(id),
  case_id TEXT REFERENCES cases(id),
  rule_type TEXT NOT NULL,
  rule_config TEXT NOT NULL,
  nag_enabled INTEGER NOT NULL DEFAULT 0,
  nag_interval_min INTEGER DEFAULT 30,
  nag_max_count INTEGER DEFAULT 6,
  respect_shift INTEGER NOT NULL DEFAULT 1,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_reminders_active ON reminders(is_active);

CREATE TABLE occurrences (
  id TEXT PRIMARY KEY,
  reminder_id TEXT NOT NULL REFERENCES reminders(id),
  task_id TEXT REFERENCES tasks(id),
  due_at TEXT NOT NULL,
  original_due_at TEXT NOT NULL,
  was_deferred INTEGER NOT NULL DEFAULT 0,
  state TEXT NOT NULL DEFAULT 'pending',
  snooze_count INTEGER NOT NULL DEFAULT 0,
  nag_count INTEGER NOT NULL DEFAULT 0,
  notif_id INTEGER,
  fired_at TEXT,
  done_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_occ_due   ON occurrences(due_at, state);
CREATE INDEX idx_occ_state ON occurrences(state);

CREATE TABLE shift_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  start_time TEXT,
  end_time TEXT,
  is_day_off INTEGER NOT NULL DEFAULT 0,
  color TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE shift_days (
  date TEXT PRIMARY KEY,
  shift_type_id TEXT NOT NULL REFERENCES shift_types(id),
  note TEXT,
  source TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE templates (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  body TEXT NOT NULL,
  is_pinned INTEGER NOT NULL DEFAULT 0,
  use_count INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE scan_batches (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  is_done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  deleted_at TEXT
);

CREATE TABLE scan_items (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES scan_batches(id),
  code TEXT NOT NULL,
  format TEXT,
  qty INTEGER NOT NULL DEFAULT 1,
  label_id TEXT,
  note TEXT,
  is_done INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_scan_batch ON scan_items(batch_id, sort_order);

CREATE TABLE lookups (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  color TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_system INTEGER NOT NULL DEFAULT 0,
  deleted_at TEXT
);
CREATE INDEX idx_lookups_kind ON lookups(kind, sort_order);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`},{version:2,name:`002_roster`,sql:`
CREATE TABLE roster_people (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  departments TEXT,
  is_me INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE roster_days (
  date TEXT NOT NULL,
  person_id TEXT NOT NULL REFERENCES roster_people(id),
  code TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  at_store INTEGER NOT NULL DEFAULT 1,
  source TEXT,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (date, person_id)
);
CREATE INDEX idx_roster_person ON roster_days(person_id, date);
`},{version:3,name:`003_case_dates`,sql:`
ALTER TABLE cases ADD COLUMN delivery_date TEXT;
ALTER TABLE cases ADD COLUMN pickup_date TEXT;
CREATE INDEX idx_cases_delivery ON cases(delivery_date);
CREATE INDEX idx_tasks_source ON tasks(source, case_id);
`},{version:4,name:`004_products`,sql:`
CREATE TABLE products (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL,
  format TEXT,
  name TEXT NOT NULL,
  price REAL,
  print_status TEXT NOT NULL DEFAULT 'pending',
  label_type TEXT NOT NULL DEFAULT 'normal',
  discount_start TEXT,
  discount_end TEXT,
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_products_code ON products(code);
CREATE INDEX idx_products_updated ON products(updated_at DESC);
`},{version:5,name:`005_documents`,sql:`
CREATE TABLE doc_folders (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE documents (
  id TEXT PRIMARY KEY,
  folder_id TEXT,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'scan',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE doc_pages (
  id TEXT PRIMARY KEY,
  document_id TEXT NOT NULL,
  position INTEGER NOT NULL,
  file TEXT NOT NULL,
  thumb TEXT NOT NULL,
  width INTEGER NOT NULL,
  height INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_documents_folder ON documents(folder_id, updated_at DESC);
CREATE INDEX idx_doc_pages_doc ON doc_pages(document_id, position);
`},{version:6,name:`006_checklist_todos`,sql:`
CREATE TABLE checklist_items (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE TABLE checklist_log (
  date TEXT NOT NULL,
  item_id TEXT NOT NULL,
  done_at TEXT NOT NULL,
  PRIMARY KEY (date, item_id)
);
CREATE TABLE todos (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  note TEXT,
  deadline_date TEXT,
  deadline_time TEXT,
  done_at TEXT,
  snooze_until TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX idx_todos_open ON todos(done_at, deadline_date);
ALTER TABLE cases ADD COLUMN product_code TEXT;
ALTER TABLE cases ADD COLUMN order_photo_id TEXT;
ALTER TABLE documents ADD COLUMN note TEXT;
`},{version:7,name:`007_label_tasks`,sql:`
ALTER TABLE products ADD COLUMN full_price REAL;
ALTER TABLE products ADD COLUMN category_id TEXT;
UPDATE products SET print_status = 'no_tag' WHERE print_status = 'pending';
UPDATE products SET print_status = 'done' WHERE print_status = 'printed';
CREATE INDEX idx_products_task ON products(print_status, updated_at DESC);
`}];async function t(e){if((await e.query(`SELECT name FROM sqlite_master WHERE type='table' AND name='meta'`)).length===0)return 0;let t=await e.query(`SELECT value FROM meta WHERE key='schema_version'`);return t[0]?Number(t[0].value):0}async function n(n,r={}){let i=r.list??e,a=await t(n),o=i.filter(e=>e.version>a).sort((e,t)=>e.version-t.version),s=i.reduce((e,t)=>Math.max(e,t.version),0);if(a>s||o.length===0)return{from:a,to:a,applied:[]};a>0&&r.beforeMigrate&&await r.beforeMigrate(a,s);let c=[];for(let e of o)await n.transaction(async()=>{await n.exec(e.sql),await n.run(`INSERT INTO meta(key, value) VALUES('schema_version', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`,[String(e.version)])}),c.push(e.name);return{from:a,to:s,applied:c}}export{n,t};